<?php 
	function clearNull($v_value)
	{
		$strRe="";
		if($v_value==0)
			$strRe="-";
		else
			$strRe=number_format($v_value,2);
		return $strRe;
	}
 ?>